// Global variables
let map;
let routeData;
let currentRoute;
let routeLayer;
let darkTileLayer;
let blankTileLayer;
let isBlankMapActive = false;
let currentRouteIndex = -1;

// Game state variables
let targetRouteIndex = -1;
let targetRoute = null;
let gameOver = false;
let wrongRouteIndices = [];
let guessCount = 0;

// Color mapping for route categories - bright colors for dark background
const categoryColors = {
    'Express': '#ff5252',
    'Frequent': '#42a5f5',
    'Light Rail': '#ffa726',
    'Local': '#b0bec5',
    'Rapid': '#ba68c8',
    'Shuttle - ACE': '#26c6da',
    'Special': '#78909c'
};

// Initialize map on page load
document.addEventListener('DOMContentLoaded', async () => {
    initializeMap();
    await loadRouteData();
    createRouteButtons();
    startNewGame();
});

function initializeMap() {
    // Create map centered on San Jose area
    map = L.map('map').setView([37.3382, -121.8863], 11);

    // Create dark grayscale tile layer
    darkTileLayer = L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_nolabels/{z}/{x}/{y}{r}.png', {
        attribution: '© CartoDB',
        maxZoom: 19,
        minZoom: 8,
        detectRetina: true
    });

    // Create completely blank dark gray tile layer
    blankTileLayer = L.tileLayer(
        'data:image/svg+xml;utf8,<svg width="256" height="256" xmlns="http://www.w3.org/2000/svg"><rect width="256" height="256" fill="%231a1a1a"/></svg>',
        {
            attribution: '',
            maxZoom: 19,
            minZoom: 8
        }
    );

    // Add dark tile layer by default
    darkTileLayer.addTo(map);

    // Initialize empty route layer
    routeLayer = L.featureGroup().addTo(map);
}

async function loadRouteData() {
    try {
        const response = await fetch('./routes/VTA.geojson');
        if (!response.ok) {
            throw new Error(`Failed to load data: ${response.statusText}`);
        }
        routeData = await response.json();
    } catch (error) {
        console.error('Error loading route data:', error);
        document.getElementById('map').classList.add('error');
        document.getElementById('map').innerHTML = `Error loading route data: ${error.message}`;
    }
}

function loadRandomRoute() {
    if (!routeData) {
        console.error('Route data not loaded yet');
        return;
    }

    const randomIndex = Math.floor(Math.random() * routeData.features.length);
    currentRouteIndex = randomIndex;
    const route = routeData.features[randomIndex];
    displayRoute(route);
    updateActiveButton(randomIndex);
}

function selectTargetRoute() {
    if (!routeData) {
        console.error('Route data not loaded');
        return;
    }
    targetRouteIndex = Math.floor(Math.random() * routeData.features.length);
    targetRoute = routeData.features[targetRouteIndex];
}

function startNewGame() {
    if (!routeData) {
        console.error('Route data not loaded yet');
        return;
    }

    // Reset game state
    gameOver = false;
    wrongRouteIndices = [];
    guessCount = 0;

    // Select new target route
    selectTargetRoute();

    // Clear map
    routeLayer.clearLayers();

    // Display target route in green
    displayRouteWithColor(targetRoute, '#00ff41');

    // Update UI
    updateGameUI();

    // Update active button
    updateActiveButton(targetRouteIndex);
}

function displayRouteWithColor(route, color) {
    const geoJsonLayer = L.geoJSON(route, {
        style: {
            color: color,
            weight: 4,
            opacity: 0.95,
            lineCap: 'round',
            lineJoin: 'round'
        }
    });

    geoJsonLayer.addTo(routeLayer);

    // Calculate bounds and fit map
    const bounds = geoJsonLayer.getBounds();
    if (bounds.isValid()) {
        map.fitBounds(bounds, { padding: [50, 50] });
    }
}

function updateGameUI() {
    const guessCountSpan = document.getElementById('guessCount');
    guessCountSpan.textContent = guessCount;

    if (gameOver) {
        // Show route details and next button
        document.getElementById('gameStatus').style.display = 'none';
        document.getElementById('routeDetails').style.display = 'flex';
        document.getElementById('btnNextRoute').style.display = 'block';
    } else {
        // Show game status
        document.getElementById('gameStatus').style.display = 'flex';
        document.getElementById('routeDetails').style.display = 'none';
        document.getElementById('btnNextRoute').style.display = 'none';
    }
}

function displayRoute(route) {
    currentRoute = route;
    const properties = route.properties;

    // Clear previous route from map
    routeLayer.clearLayers();

    // Add new route to map
    const geoJsonLayer = L.geoJSON(route, {
        style: {
            color: categoryColors[properties.category] || '#667eea',
            weight: 4,
            opacity: 0.95,
            lineCap: 'round',
            lineJoin: 'round'
        }
    });

    geoJsonLayer.addTo(routeLayer);

    // Calculate bounds and fit map
    const bounds = geoJsonLayer.getBounds();
    if (bounds.isValid()) {
        map.fitBounds(bounds, { padding: [50, 50] });
    }

    // Update UI with route information
    updateRouteInfo(properties);
}

function updateRouteInfo(properties) {
    document.getElementById('routeNumber').textContent = properties.lineabbr;
    document.getElementById('routeName').textContent = properties.linename;
    document.getElementById('routeCategory').textContent = properties.category;
}

function toggleBlankMap() {
    const button = document.querySelector('.btn-toggle');

    if (isBlankMapActive) {
        // Switch back to dark map
        map.removeLayer(blankTileLayer);
        darkTileLayer.addTo(map);
        button.classList.remove('active');
        isBlankMapActive = false;
    } else {
        // Switch to blank map
        map.removeLayer(darkTileLayer);
        blankTileLayer.addTo(map);
        button.classList.add('active');
        isBlankMapActive = true;
    }
}

function createRouteButtons() {
    if (!routeData || !routeData.features) {
        console.error('Route data not available');
        return;
    }

    const container = document.getElementById('routesContainer');
    container.innerHTML = ''; // Clear existing buttons

    routeData.features.forEach((feature, index) => {
        const properties = feature.properties;
        const button = document.createElement('button');
        button.className = 'route-btn';
        button.textContent = properties.lineabbr;
        button.setAttribute('data-index', index);
        button.onclick = () => onRouteButtonClick(index);
        container.appendChild(button);
    });
}

function onRouteButtonClick(routeIndex) {
    if (!routeData || !routeData.features[routeIndex]) {
        console.error('Invalid route index:', routeIndex);
        return;
    }

    if (gameOver) {
        return; // Prevent clicking buttons after game is over
    }

    guessCount++;
    updateGameUI();

    if (routeIndex === targetRouteIndex) {
        // Correct guess!
        gameOver = true;
        currentRoute = targetRoute;
        updateRouteInfo(targetRoute.properties);
        updateGameUI();
    } else {
        // Wrong guess
        if (!wrongRouteIndices.includes(routeIndex)) {
            wrongRouteIndices.push(routeIndex);
        }

        // Display the wrong route in red
        const wrongRoute = routeData.features[routeIndex];
        displayRouteWithColor(wrongRoute, '#ff1744');
    }
}

function updateActiveButton(routeIndex) {
    // Remove active class from all buttons
    document.querySelectorAll('.route-btn').forEach(btn => {
        btn.classList.remove('active');
    });

    // Add active class to clicked button
    const activeButton = document.querySelector(`[data-index="${routeIndex}"]`);
    if (activeButton) {
        activeButton.classList.add('active');
        // Scroll button into view
        activeButton.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
}
